#include "platform.h"
#if __FLASHROM_LITTLE_ENDIAN__
little
#else
big
#endif

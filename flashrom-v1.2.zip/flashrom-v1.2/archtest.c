#include "platform.h"
__FLASHROM_ARCH__
